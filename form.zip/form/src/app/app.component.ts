import { Component } from '@angular/core';
import { User } from './user';
import { EnrollmentService } from './enrollment.service';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
genders=['male','female','other'];
genderHasError=true;
errorMsg='';
userModel=new User('Varsha','var@gmail.com',999999,'default','morning',true);


constructor(private _enrollmentService:EnrollmentService){}

validateGender(value:any){
if(value=='default')
{ this.genderHasError=true;

}
else {
  this.genderHasError=false;
}
}
onSubmit(){
this._enrollmentService.enroll(this.userModel).subscribe(
  data =>console.log('Success',data),
  error=>this.errorMsg=error.statusText
  
)

}
}
