const express=require('express');
const cors=require('cors');

const PORT=3000;

const app=express();


app.use(express.json());


app.use(cors());

app.get('/',function(req,res){
res.send('Hello from server');

})
app.post('/enroll',function(req,res){
console.log(req.body);
res.status(401).send({"message":"data received"});
})

app.listen(PORT,function(){
console.log("server running on localhost"+PORT);

});