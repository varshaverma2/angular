export class User {
constructor(
  public name: string,
  public email:string,
  public phone:number,
  public gender:string,
  public timePreference:string,
  public subscribe:boolean
)
{}


}
